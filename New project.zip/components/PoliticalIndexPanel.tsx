import type { PoliticalIndex } from "@/data/works";

type Item = {
  label: string;
  value: number;
  help: string;
};

type PressureLevel = {
  label: "極低" | "低" | "中" | "高" | "極高";
  range: string;
  color: string;
  dot: string;
  text: string;
};

const items = (index: PoliticalIndex): Item[] => [
  {
    label: "多元代表性",
    value: index.representation,
    help: "衡量角色、族群、文化與身份差異是否被明確呈現。高分代表代表性會成為討論焦點之一。",
  },
  {
    label: "原作忠實度",
    value: index.canonFaithful,
    help: "衡量作品是否保留原作角色、世界觀、核心事件與粉絲期待。高分通常降低原作粉反彈。",
  },
  {
    label: "改編自由度",
    value: index.adaptationFreedom,
    help: "衡量作品是否大幅重寫設定、角色或主題。高分代表創作自由高，但也可能提高改編爭議。",
  },
  {
    label: "議題置入程度",
    value: index.issueInsertion,
    help: "衡量社會議題是否只是背景，或已成為角色衝突、宣傳語言與作品主軸。",
  },
  {
    label: "爭議風險",
    value: index.controversyRisk,
    help: "衡量作品在選角、文本、行銷或社群討論中引發文化爭議的可能性。",
  },
  {
    label: "媒體友善度",
    value: index.mediaFriendly,
    help: "衡量作品是否容易被影評、媒體或專欄用當代評論語言稱讚與解讀。",
  },
  {
    label: "觀眾分裂度",
    value: index.audienceSplit,
    help: "衡量媒體、粉絲、玩家或一般觀眾之間是否可能出現明顯評價落差。",
  },
];

const levels: PressureLevel[] = [
  {
    label: "極低",
    range: "1.0-2.4",
    color: "bg-emerald-300",
    dot: "bg-emerald-300",
    text: "文化壓力極低：評價多半集中在娛樂性、技術、玩法或敘事完成度。",
  },
  {
    label: "低",
    range: "2.5-4.9",
    color: "bg-lime-300",
    dot: "bg-lime-300",
    text: "文化壓力低：政治正確因素存在，但通常不是評價成敗的主戰場。",
  },
  {
    label: "中",
    range: "5.0-6.9",
    color: "bg-amber-300",
    dot: "bg-amber-300",
    text: "文化壓力中：議題、改編與代表性會影響討論，但完成度仍能扭轉觀感。",
  },
  {
    label: "高",
    range: "7.0-8.4",
    color: "bg-orange-300",
    dot: "bg-orange-300",
    text: "文化壓力高：行銷、選角、原作改動與媒體敘事會顯著影響第一印象。",
  },
  {
    label: "極高",
    range: "8.5-10",
    color: "bg-rose-300",
    dot: "bg-rose-300",
    text: "文化壓力極高：作品容易被放進文化戰框架，觀眾分裂與平台評價落差會更明顯。",
  },
];

const getLevel = (score: number) => {
  if (score >= 85) return levels[4];
  if (score >= 70) return levels[3];
  if (score >= 50) return levels[2];
  if (score >= 25) return levels[1];
  return levels[0];
};

const barColor = (value: number) => getLevel(value).color;
const formatScore = (value: number) => (value / 10).toFixed(1);

export function PoliticalIndexPanel({ index }: { index: PoliticalIndex }) {
  const pressureScore = Math.round(
    (index.representation +
      index.adaptationFreedom +
      index.issueInsertion +
      index.controversyRisk +
      index.audienceSplit +
      (100 - index.canonFaithful)) /
      6,
  );
  const pressureLevel = getLevel(pressureScore);

  return (
    <section className="rounded-lg border border-white/10 bg-white/[0.06] p-5 shadow-glow backdrop-blur">
      <div className="mb-5 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-white">政治正確影響指標</h2>
          <p className="mt-1 text-sm text-slate-300">依 mock data 模擬文化評價壓力，換算為 1-10 分。</p>
        </div>
        <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-slate-300">
          PC Impact
        </span>
      </div>

      <div className="mb-6 rounded-lg border border-white/10 bg-black/25 p-4">
        <p className="text-xs uppercase tracking-[0.18em] text-slate-400">文化壓力分級</p>
        <div className="mt-3 flex items-end gap-3">
          <span className={`text-6xl font-black leading-none text-transparent bg-clip-text ${pressureLevel.color.replace("bg-", "bg-")}`}>
            {pressureLevel.label}
          </span>
          <span className="pb-2 font-mono text-lg text-slate-200">{formatScore(pressureScore)} / 10</span>
        </div>
        <p className="mt-3 text-sm leading-6 text-slate-300">{pressureLevel.text}</p>
      </div>

      <div className="space-y-4">
        {items(index).map((item) => (
          <div key={item.label} className="group relative">
            <div className="mb-2 flex items-center justify-between gap-3 text-sm">
              <span className="cursor-help text-slate-200 underline decoration-white/20 underline-offset-4">
                {item.label}
              </span>
              <span className="font-mono text-slate-100">{formatScore(item.value)} / 10</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-white/10">
              <div
                className={`h-full rounded-full ${barColor(item.value)}`}
                style={{ width: `${item.value}%` }}
              />
            </div>
            <div className="pointer-events-none absolute left-0 top-8 z-40 min-w-[16rem] max-w-sm rounded-lg border border-white/15 bg-slate-950/95 px-4 py-3 text-sm leading-6 text-slate-100 opacity-0 shadow-xl backdrop-blur transition group-hover:opacity-100">
              {item.help}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-lg border border-white/10 bg-black/20 p-4">
        <div className="mb-3 flex flex-wrap gap-3 text-xs text-slate-300">
          {levels.map((level) => (
            <span key={level.label} className="inline-flex items-center gap-2">
              <span className={`h-2.5 w-2.5 rounded-full ${level.dot}`} />
              {level.label} {level.range}
            </span>
          ))}
        </div>
        <p className="text-sm leading-6 text-slate-300">
          顏色代表文化壓力的警戒程度，不代表作品好壞。越綠代表越安全，越紅代表越容易進入爭議、
          改編正當性、媒體敘事或觀眾分裂的討論。
        </p>
      </div>
    </section>
  );
}
