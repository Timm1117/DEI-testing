"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Clapperboard, Crosshair, Gamepad2 } from "lucide-react";
import { questions } from "@/data/questions";
import type { WorkType } from "@/data/works";
import { applyEffects, createEmptyProfile, normalizeProfile, type UserProfile } from "@/lib/matchWork";

const clamp = (value: number) => Math.max(0, Math.min(100, value));

const axisFromProfile = (profile: UserProfile | null) => {
  if (!profile) return { x: 50, y: 50 };

  const { tags } = normalizeProfile(profile);

  return {
    x: clamp(
      tags.representation * 0.38 +
        tags.genderPowerShift * 0.24 +
        tags.issueInsertion * 0.2 +
        tags.mediaFriendly * 0.1 +
        (100 - tags.canonFaithful) * 0.08,
    ),
    y: clamp(tags.controversyRisk * 0.58 + tags.issueInsertion * 0.27 + (100 - tags.canonFaithful) * 0.15),
  };
};

function AxisPanel({
  profile,
  selectedType,
}: {
  profile: UserProfile | null;
  selectedType: WorkType;
}) {
  const current = axisFromProfile(profile);
  const deiLevel = current.x >= 72 ? "高 DEI" : current.x >= 45 ? "中 DEI" : "低 DEI";
  const controversyLevel = current.y >= 72 ? "高爭議" : current.y >= 45 ? "中爭議" : "低爭議";

  return (
    <aside className="rounded-lg border border-white/10 bg-black/25 p-5 shadow-glow backdrop-blur">
      <div className="mb-4 flex items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-teal-200">POSITIONING</p>
          <h2 className="mt-1 text-lg font-bold text-white">作品定位</h2>
        </div>
        <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-slate-300">
          {selectedType === "film" ? "影視" : "遊戲"}
        </span>
      </div>

      <div className="relative aspect-square overflow-hidden rounded-lg border border-white/10 bg-slate-950/80">
        <div className="absolute inset-4 border-l border-b border-white/25" />
        <div className="absolute left-1/2 top-4 h-[calc(100%-2rem)] w-px bg-white/10" />
        <div className="absolute left-4 top-1/2 h-px w-[calc(100%-2rem)] bg-white/10" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.055)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.055)_1px,transparent_1px)] bg-[size:20%_20%]" />

        <div
          className="absolute z-20 flex h-6 w-6 items-center justify-center rounded-full border border-teal-100 bg-teal-300 shadow-[0_0_24px_rgba(94,234,212,0.85)] transition-all duration-500"
          style={{ left: `${current.x}%`, top: `${100 - current.y}%`, transform: "translate(-50%, -50%)" }}
        >
          <Crosshair size={14} className="text-slate-950" />
        </div>

        <span className="absolute left-4 top-3 text-[11px] font-semibold text-slate-400">爭議程度高</span>
        <span className="absolute bottom-3 left-4 text-[11px] font-semibold text-slate-400">DEI 程度低</span>
        <span className="absolute bottom-3 right-4 text-[11px] font-semibold text-slate-400">DEI 程度高</span>
        <span className="absolute left-4 bottom-10 text-[11px] font-semibold text-slate-500">爭議程度低</span>
      </div>

      <div className="mt-4 rounded-md border border-white/10 bg-white/[0.04] p-3 text-sm">
        <p className="font-semibold text-white">
          {deiLevel} / {controversyLevel}
        </p>
        <p className="mt-1 text-xs leading-5 text-slate-400">越往右 DEI 越高，越往上爭議越高。</p>
      </div>

      <p className="mt-3 text-xs leading-5 text-slate-400">
        每次製作決策都會改變作品定位，最後會用這個輪廓尋找最接近的作品。
      </p>
    </aside>
  );
}

export default function QuizPage() {
  const router = useRouter();
  const [selectedType, setSelectedType] = useState<WorkType | null>(null);
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState<UserProfile | null>(null);

  const activeQuestions = useMemo(
    () =>
      selectedType
        ? questions.filter((question) => question.appliesTo === "all" || question.appliesTo === selectedType)
        : [],
    [selectedType],
  );

  const start = (type: WorkType) => {
    setSelectedType(type);
    setProfile(createEmptyProfile(type));
    setStep(0);
  };

  const answer = (effects: Parameters<typeof applyEffects>[1], matchTags: Parameters<typeof applyEffects>[2]) => {
    if (!profile) return;

    const nextProfile = applyEffects(profile, effects, matchTags);

    if (step >= activeQuestions.length - 1) {
      window.localStorage.setItem("pc-quiz-profile", JSON.stringify(nextProfile));
      router.push("/result");
      return;
    }

    setProfile(nextProfile);
    setStep((current) => current + 1);
  };

  if (!selectedType) {
    return (
      <main className="min-h-screen px-5 py-10">
        <div className="mx-auto flex min-h-[calc(100vh-5rem)] max-w-5xl flex-col justify-center">
          <p className="mb-3 text-sm font-medium uppercase tracking-[0.25em] text-teal-200">Step 0</p>
          <h1 className="text-4xl font-black text-white sm:text-5xl">你要製作哪一種作品？</h1>
          <p className="mt-4 max-w-2xl leading-7 text-slate-300">
            先選媒介，後續題目會依影視或遊戲切換，最後只會在同類作品中比對推薦。
          </p>

          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            <button
              type="button"
              onClick={() => start("film")}
              className="group rounded-lg border border-white/10 bg-white/[0.07] p-6 text-left transition hover:border-teal-200/60 hover:bg-white/[0.11]"
            >
              <Clapperboard className="mb-8 text-teal-200" size={34} />
              <h2 className="text-2xl font-semibold text-white">影視作品</h2>
              <p className="mt-3 text-sm leading-6 text-slate-300">
                偏向選角、獎季、票房、原作改編與影評語境。
              </p>
              <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-teal-200">
                選擇影視
                <ArrowRight size={16} className="transition group-hover:translate-x-1" />
              </span>
            </button>

            <button
              type="button"
              onClick={() => start("game")}
              className="group rounded-lg border border-white/10 bg-white/[0.07] p-6 text-left transition hover:border-amber-200/60 hover:bg-white/[0.11]"
            >
              <Gamepad2 className="mb-8 text-amber-200" size={34} />
              <h2 className="text-2xl font-semibold text-white">遊戲作品</h2>
              <p className="mt-3 text-sm leading-6 text-slate-300">
                加入商業模式、玩家自由度、劇情導向與社群反應。
              </p>
              <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-amber-200">
                選擇遊戲
                <ArrowRight size={16} className="transition group-hover:translate-x-1" />
              </span>
            </button>
          </div>
        </div>
      </main>
    );
  }

  const current = activeQuestions[step];
  const progress = Math.round(((step + 1) / activeQuestions.length) * 100);

  return (
    <main className="min-h-screen px-5 py-8">
      <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-6xl flex-col justify-center">
        <div className="mb-8">
          <button
            onClick={() => {
              if (step === 0) {
                setSelectedType(null);
                setProfile(null);
                return;
              }
              setStep((currentStep) => currentStep - 1);
            }}
            className="mb-6 inline-flex items-center gap-2 text-sm text-slate-300 transition hover:text-white"
          >
            <ArrowLeft size={16} />
            返回
          </button>

          <div className="mb-4 h-2 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-teal-300 transition-all" style={{ width: `${progress}%` }} />
          </div>
          <div className="flex items-center justify-between gap-4 text-sm text-slate-300">
            <span>{selectedType === "film" ? "影視作品" : "遊戲作品"}</span>
            <span>
              {step + 1} / {activeQuestions.length}
            </span>
          </div>
        </div>

        <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_20rem]">
          <section className="rounded-lg border border-white/10 bg-white/[0.06] p-5 shadow-glow backdrop-blur sm:p-8">
            <p className="mb-3 text-sm font-medium uppercase tracking-[0.22em] text-teal-200">Production Decision</p>
            <h1 className="text-3xl font-black leading-tight text-white sm:text-4xl">{current.title}</h1>
            {current.subtitle ? <p className="mt-3 text-slate-300">{current.subtitle}</p> : null}

            <div className="mt-8 grid gap-3">
              {current.options.map((option) => {
                return (
                  <button
                    type="button"
                    key={option.label}
                    onClick={() => answer(option.effects, option.matchTags)}
                    className="rounded-lg border border-white/10 bg-black/20 p-5 text-left transition hover:border-teal-200/60 hover:bg-teal-200/10 focus:border-teal-200/70 focus:bg-teal-200/10 focus:outline-none"
                  >
                  <span className="flex gap-4">
                    {option.imageSrc ? (
                      <span className="flex h-24 w-24 shrink-0 items-end justify-center overflow-hidden rounded-md border border-white/10 bg-slate-950/80">
                        <img
                          src={option.imageSrc}
                          alt={option.imageAlt ?? option.label}
                          className="max-h-full max-w-full object-contain"
                        />
                      </span>
                    ) : null}
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-start justify-between gap-3">
                        <span className="text-lg font-semibold text-white">{option.label}</span>
                      </span>
                      <span className="mt-2 block text-sm leading-6 text-slate-300">{option.description}</span>
                    </span>
                  </span>
                  </button>
                );
              })}
            </div>
          </section>

          <AxisPanel profile={profile} selectedType={selectedType} />
        </div>
      </div>
    </main>
  );
}
