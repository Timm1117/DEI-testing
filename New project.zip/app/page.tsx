import Link from "next/link";
import { Clapperboard, Gamepad2, MoveRight } from "lucide-react";

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <section className="relative flex min-h-screen items-center overflow-hidden px-5 py-10">
        <div
          className="absolute inset-0 -z-10 bg-cover bg-center opacity-30"
          style={{
            backgroundImage:
              "url(https://images.unsplash.com/photo-1603739903239-8b6e64c3b185?auto=format&fit=crop&w=1800&q=80)",
          }}
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-black via-black/80 to-black/30" />

        <div className="mx-auto grid w-full max-w-6xl gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
          <div>
            <p className="mb-4 text-sm font-medium uppercase tracking-[0.28em] text-teal-200">
              Interactive Production Quiz
            </p>
            <h1 className="max-w-4xl text-4xl font-black leading-tight text-white sm:text-6xl">
              政治正確對影視與遊戲產業評價的影響
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-8 text-slate-200 sm:text-lg">
              你將扮演創作者，回答一系列製作決策。系統會把你的選擇轉成作品標籤，
              再與真實電影或遊戲的 mock data 比對，推薦最相似的一部作品。
            </p>
            <Link
              href="/quiz"
              className="mt-8 inline-flex items-center gap-2 rounded-lg bg-teal-300 px-5 py-3 font-semibold text-slate-950 transition hover:bg-teal-200"
            >
              開始製作測驗
              <MoveRight size={18} />
            </Link>
          </div>

          <div className="grid gap-3">
            <div className="rounded-lg border border-white/10 bg-white/[0.07] p-5 backdrop-blur">
              <Clapperboard className="mb-4 text-teal-200" size={28} />
              <h2 className="text-xl font-semibold text-white">影視作品</h2>
              <p className="mt-2 text-sm leading-6 text-slate-300">
                追蹤改編忠實度、選角代表性、媒體友善度與觀眾分裂風險。
              </p>
            </div>
            <div className="rounded-lg border border-white/10 bg-white/[0.07] p-5 backdrop-blur">
              <Gamepad2 className="mb-4 text-amber-200" size={28} />
              <h2 className="text-xl font-semibold text-white">遊戲作品</h2>
              <p className="mt-2 text-sm leading-6 text-slate-300">
                加入商業模式、玩家自由度、劇情導向與社群接受度等決策。
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
