"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { RotateCcw } from "lucide-react";
import { Danmaku } from "@/components/Danmaku";
import { ControversyTimeline } from "@/components/ControversyTimeline";
import { PoliticalIndexPanel } from "@/components/PoliticalIndexPanel";
import { RatingCard } from "@/components/RatingCard";
import { formatShare, getResultStat, rarityLabel } from "@/data/resultStats";
import { matchWork, type UserProfile } from "@/lib/matchWork";
import type { Work } from "@/data/works";

const buildTraitTags = (work: Work) => {
  const tags = [
    work.type === "film" ? "影視作品" : "遊戲作品",
    work.tags.commercialEntertainment >= 80 ? "商業娛樂性高" : null,
    work.tags.genrePrestige >= 80 ? "評論口碑型" : null,
    work.tags.genreSpectacle >= 80 ? "奇觀導向" : null,
    work.tags.adaptation >= 70 ? "IP / 原作改編" : "原創傾向",
    work.tags.canonFaithful >= 75 ? "原作忠實" : null,
    work.tags.canonFaithful <= 40 ? "大幅改編" : null,
    work.tags.representation >= 75 ? "高 DEI 代表性" : null,
    work.tags.representation <= 35 && work.tags.issueInsertion <= 35 ? "低 DEI 對照" : null,
    work.tags.issueInsertion >= 75 ? "議題濃度高" : null,
    work.tags.controversyRisk >= 75 ? "高爭議風險" : null,
    work.tags.mediaFriendly >= 80 ? "媒體友善" : null,
    work.tags.audienceAcceptance >= 80 ? "觀眾接受度高" : null,
    work.tags.playerFreedom >= 80 ? "高玩家自由度" : null,
    work.tags.storyDriven >= 80 ? "劇情導向" : null,
    work.tags.monetizationPressure >= 50 ? "營運壓力高" : null,
  ].filter(Boolean);

  return Array.from(new Set(tags)).slice(0, 12) as string[];
};

const buildReceptionInsight = (work: Work) => {
  const pcPressure =
    (work.politicalIndex.representation +
      work.politicalIndex.adaptationFreedom +
      work.politicalIndex.issueInsertion +
      work.politicalIndex.controversyRisk +
      work.politicalIndex.audienceSplit +
      (100 - work.politicalIndex.canonFaithful)) /
    6;

  if (work.tags.audienceAcceptance >= 80 && pcPressure < 45) {
    return "這類作品通常靠完成度、類型爽感或玩家體驗取勝，政治正確因素不是主要評價戰場。";
  }

  if (work.tags.audienceAcceptance >= 80 && work.politicalIndex.representation >= 75) {
    return "這類作品的代表性沒有拖累評價，因為它同時維持了娛樂性、角色功能或玩法完成度。";
  }

  if (work.politicalIndex.audienceSplit >= 75 && work.politicalIndex.controversyRisk >= 75) {
    return "這類作品容易被放進文化戰框架。若原作忠實度或娛樂性不足，觀眾反感會快速放大。";
  }

  if (work.tags.storyDriven >= 80 && work.tags.playerFreedom <= 40) {
    return "這類作品由作者強力控制敘事，媒體可能欣賞主題，但玩家或觀眾會更在意是否被迫接受角色命運。";
  }

  if (work.tags.playerFreedom >= 80 && work.politicalIndex.issueInsertion >= 70) {
    return "這類作品即使議題濃度高，也能靠自由度讓玩家自行消化立場，因此比較不容易被單一價值標籤綁死。";
  }

  return "這類作品的評價取決於議題、娛樂性、原作處理與受眾期待是否能彼此支撐。";
};

const buildSimilarityCopy = (similarity: number) => {
  if (similarity >= 76) {
    return {
      label: "高度相似",
      body: "你的製作取向和這部作品的文化壓力、娛樂性與受眾反應高度接近。",
    };
  }

  if (similarity >= 60) {
    return {
      label: "中度相似",
      body: "這是目前資料庫中相當接近的對照樣本，但仍有幾個面向不完全重疊。",
    };
  }

  return {
    label: "最接近樣本",
    body: "這是目前資料庫裡最接近的作品，不代表高度相似；你的答案可能落在資料庫樣本仍不足的區域。",
  };
};

export default function ResultPage() {
  const [profile, setProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    const raw = window.localStorage.getItem("pc-quiz-profile");
    if (!raw) return;

    try {
      setProfile(JSON.parse(raw) as UserProfile);
    } catch {
      window.localStorage.removeItem("pc-quiz-profile");
    }
  }, []);

  const result = useMemo(() => (profile ? matchWork(profile) : null), [profile]);

  if (!result) {
    return (
      <main className="flex min-h-screen items-center justify-center px-5">
        <section className="max-w-md rounded-lg border border-white/10 bg-white/[0.07] p-6 text-center">
          <h1 className="text-2xl font-bold text-white">還沒有測驗結果</h1>
          <p className="mt-3 text-sm leading-6 text-slate-300">
            先完成製作決策，系統才會推薦相似作品。
          </p>
          <Link
            href="/quiz"
            className="mt-6 inline-flex items-center justify-center rounded-lg bg-teal-300 px-5 py-3 font-semibold text-slate-950 transition hover:bg-teal-200"
          >
            前往測驗
          </Link>
        </section>
      </main>
    );
  }

  const { work, similarity } = result;
  const traitTags = buildTraitTags(work);
  const receptionInsight = buildReceptionInsight(work);
  const similarityCopy = buildSimilarityCopy(similarity);
  const resultStat = getResultStat(work.id);
  const rarity = rarityLabel(resultStat.share);

  return (
    <main className="min-h-screen bg-[#090a0f]">
      <Danmaku comments={work.comments} />

      <section className="relative min-h-screen overflow-hidden px-5 py-10">
        <div
          className="absolute inset-0 -z-30 bg-cover bg-center"
          style={{ backgroundImage: `url(${work.backgroundImage})` }}
        />
        <div className="absolute inset-0 -z-20 bg-gradient-to-r from-[#090a0f]/95 via-[#090a0f]/72 to-[#090a0f]/42" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-[#090a0f]/30 via-[#090a0f]/60 to-[#090a0f]" />

        <div className="relative z-20 mx-auto max-w-6xl">
          <div className="grid min-h-[84vh] gap-8 pt-12 lg:grid-cols-[0.95fr_1.05fr] lg:items-end">
            <div>
              <p className="mb-4 text-sm font-medium uppercase tracking-[0.25em] text-teal-200">
                Most Similar Work
              </p>
              <h1 className="max-w-4xl text-4xl font-black leading-tight text-white sm:text-6xl">
                {work.title}
              </h1>
              {work.originalTitle ? (
                <p className="mt-3 text-xl font-medium text-slate-300 sm:text-2xl">{work.originalTitle}</p>
              ) : null}
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <span className="rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm text-white">
                  {work.year}
                </span>
                <span className="rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm text-white">
                  {work.type === "film" ? "電影" : "遊戲"}
                </span>
              </div>
              <div className="mt-5 flex max-w-2xl flex-wrap gap-2">
                {traitTags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-teal-200/20 bg-teal-200/10 px-3 py-1 text-xs font-medium text-teal-100"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <p className="mt-6 max-w-2xl text-base leading-8 text-slate-100">{work.synopsis}</p>
              <div className="mt-5 max-w-2xl rounded-lg border border-white/10 bg-black/30 p-4 backdrop-blur">
                <p className="text-xs uppercase tracking-[0.18em] text-slate-400">評價門檻推論</p>
                <p className="mt-2 text-sm leading-6 text-slate-200">{receptionInsight}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="overflow-hidden rounded-lg border border-white/15 bg-black/35 shadow-glow backdrop-blur">
                <img
                  src={work.coverImage}
                  alt={`${work.title} artwork`}
                  className="aspect-video w-full bg-black object-contain"
                />
                <div className="border-t border-white/10 px-5 py-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">作品圖像識別</p>
                  <p className="mt-1 text-xl font-semibold text-white">{work.title}</p>
                  {work.originalTitle ? (
                    <p className="mt-1 text-sm text-slate-400">{work.originalTitle}</p>
                  ) : null}
                </div>
              </div>

              <div className="rounded-lg border border-teal-200/30 bg-black/45 p-6 shadow-glow backdrop-blur">
                <div className="text-sm text-slate-300">相似度</div>
                <div className="mt-3 text-6xl font-black text-teal-200">{similarity}%</div>
                <div className="mt-5 h-3 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-teal-300" style={{ width: `${similarity}%` }} />
                </div>
                <div className="mt-4 rounded-lg border border-white/10 bg-white/[0.06] p-4">
                  <div className="text-sm font-semibold text-white">{similarityCopy.label}</div>
                  <p className="mt-2 text-xs leading-5 text-slate-400">{similarityCopy.body}</p>
                </div>
                <div className="mt-5 rounded-lg border border-white/10 bg-white/[0.06] p-4">
                  <div className="flex flex-wrap items-end justify-between gap-3">
                    <div>
                      <p className="text-xs uppercase tracking-[0.18em] text-slate-400">Result Rarity</p>
                      <p className="mt-1 text-sm text-slate-200">
                        你與{" "}
                        <span className="font-mono text-lg font-bold text-teal-200">
                          {formatShare(resultStat.share)}
                        </span>{" "}
                        的人一樣
                      </p>
                    </div>
                    <span className="rounded-full border border-teal-200/30 bg-teal-200/10 px-3 py-1 text-sm font-semibold text-teal-100">
                      {rarity}
                    </span>
                  </div>
                  <p className="mt-2 text-xs leading-5 text-slate-400">
                    依本地 mock 模擬 {resultStat.sampleSize.toLocaleString()} 次測驗估算。
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-5 pb-10 lg:grid-cols-[1fr_1fr]">
            <PoliticalIndexPanel index={work.politicalIndex} />
            <div className="space-y-5">
              <RatingCard ratings={work.ratings} type={work.type} />
              <ControversyTimeline work={work} />
            </div>
          </div>

          <div className="pb-12">
            <Link
              href="/quiz"
              onClick={() => window.localStorage.removeItem("pc-quiz-profile")}
              className="inline-flex items-center gap-2 rounded-lg bg-white px-5 py-3 font-semibold text-slate-950 transition hover:bg-slate-200"
            >
              <RotateCcw size={18} />
              重新測驗
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
